﻿'use strict';
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function (req, res) {
    //localhost:3000?method=add&x=1&y=2
    console.log(req.query.method);
    res.render('index', { title: 'Express' });
});

module.exports = router;
